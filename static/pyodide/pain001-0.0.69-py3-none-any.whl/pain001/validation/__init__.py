# Copyright (C) 2023-2026 Pain001. All rights reserved.
# SPDX-License-Identifier: Apache-2.0 OR MIT
#
# Licensed under either of the Apache License, Version 2.0 or the MIT
# License, at your option. You may not use this file except in
# compliance with one of those licences. Copies are provided in
# LICENSE-APACHE and LICENSE-MIT.
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licences is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied. See the applicable Licence for the specific language
# governing permissions and limitations.

"""Validation module for Pain001.

This module provides centralized validation services for payment data,
templates, schemas, and data sources.
"""

from pain001.schemas.required_columns import required_columns
from pain001.validation.bic_validator import (
    validate_bic,
    validate_bic_format,
    validate_bic_safe,
)
from pain001.validation.charset import (
    ISO20022_ALLOWED_CHARACTERS,
    find_invalid_characters,
    is_valid_charset,
    sanitize_to_charset,
)
from pain001.validation.iban_validator import (
    validate_iban,
    validate_iban_checksum,
    validate_iban_format,
    validate_iban_safe,
)
from pain001.validation.rails import (
    PURPOSE_MANDATES,
    RAILS,
    PurposeMandate,
    Rail,
    RailProfile,
)
from pain001.validation.schemes import (
    PROFILES,
    REMEDIATIONS,
    AntiDuplicateProfile,
    CrossBorderCreditTransferProfile,
    SchemeValidationResult,
    SchemeViolation,
    SepaCreditTransferProfile,
    SepaDirectDebitProfile,
    SepaInstantCreditTransferProfile,
    ValidationProfile,
    remediation_for,
    validate_scheme,
)
from pain001.validation.service import (
    ValidationConfig,
    ValidationReport,
    ValidationResult,
    ValidationService,
)

__all__ = [
    # Service classes
    "ValidationService",
    "ValidationConfig",
    "ValidationResult",
    "ValidationReport",
    # IBAN validation
    "validate_iban",
    "validate_iban_format",
    "validate_iban_checksum",
    "validate_iban_safe",
    # BIC validation
    "validate_bic",
    "validate_bic_format",
    "validate_bic_safe",
    # ISO 20022 character set
    "ISO20022_ALLOWED_CHARACTERS",
    "find_invalid_characters",
    "is_valid_charset",
    "sanitize_to_charset",
    # Scheme rulebook validation
    "validate_scheme",
    "ValidationProfile",
    "SepaCreditTransferProfile",
    "SepaDirectDebitProfile",
    "SepaInstantCreditTransferProfile",
    "CrossBorderCreditTransferProfile",
    "AntiDuplicateProfile",
    "SchemeValidationResult",
    "SchemeViolation",
    "PROFILES",
    "REMEDIATIONS",
    "remediation_for",
    # Rail rulebooks
    "RAILS",
    "PURPOSE_MANDATES",
    "Rail",
    "RailProfile",
    "PurposeMandate",
    # Required-column contract
    "required_columns",
]
