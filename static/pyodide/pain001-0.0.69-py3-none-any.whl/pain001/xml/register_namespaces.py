# Copyright (C) 2023-2026 Pain001. All rights reserved.
# SPDX-License-Identifier: Apache-2.0 OR MIT
#
# Licensed under either of the Apache License, Version 2.0 or the MIT
# License, at your option. You may not use this file except in
# compliance with one of those licences. Copies are provided in
# LICENSE-APACHE and LICENSE-MIT.
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licences is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied. See the applicable Licence for the specific language
# governing permissions and limitations.

"""Register ISO 20022 XML namespaces for ElementTree serialization."""

import xml.etree.ElementTree as et  # nosec B405

# Register the namespace prefixes with the ElementTree module so that
# they are automatically added to the XML tags when the XML elements
# are created (XML tags and CSV columns mapping)


def register_namespaces(payment_initiation_message_type: str) -> None:
    """This function registers the namespaces for the payment initiation
    message type.

    Args:
        payment_initiation_message_type: The payment initiation message
            type (e.g. "pain.001.001.03").
    """

    # Create the namespace for the payment initiation message type.
    namespace = (
        "urn:iso:std:iso:20022:tech:xsd:" + payment_initiation_message_type
    )

    # Register the namespaces.
    et.register_namespace("", namespace)
    et.register_namespace("xsi", "http://www.w3.org/2001/XMLSchema-instance")
